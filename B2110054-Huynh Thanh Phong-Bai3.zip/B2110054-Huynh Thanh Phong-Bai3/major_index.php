<?php
// Kết nối đến cơ sở dữ liệu
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM major";
$result = $conn->query($sql);

echo "<h2>Danh sách chuyên ngành</h2>";
echo "<a href='major_add.php'>Thêm chuyên ngành mới</a>";
echo "<table border='1'>";
echo "<tr><th>ID</th><th>Tên chuyên ngành</th><th>Hành động</th></tr>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['name_major']}</td>
            <td>
                <a href='major_edit.php?id={$row['id']}'>Sửa</a> |
                <a href='major_xoa.php?id={$row['id']}'>Xóa</a>
            </td>
        </tr>";
    }
}
echo "</table>";

$conn->close();
