<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $name_major = $_POST['name_major'];

    $sql = "UPDATE major SET name_major = '$name_major' WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        echo "Cập nhật thành công";
        header('Location: major_index.php');
    } else {
        echo "Lỗi: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}
