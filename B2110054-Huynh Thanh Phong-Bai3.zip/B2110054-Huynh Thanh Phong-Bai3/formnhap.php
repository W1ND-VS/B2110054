<!DOCTYPE HTML>
<html>

<body>
    <form action="luu.php" method="post">

        Name: <input type="text" name="name"><br>
        E-mail: <input type="text" name="email"><br>
        Birthday: <input type="date" name="birth"><br>

        <label for="major_id">Chuyên ngành:</label>
        <select name="major_id" required>
            <option value="">--Chọn chuyên ngành--</option>
            <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "qlsv";
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            //tao chuoi luu cau lenh sql
            $sql = "SELECT * FROM student";
            // Truy vấn danh sách các chuyên ngành từ bảng major
            $sql_major = "SELECT id, name_major FROM major";
            $result_major = $conn->query($sql_major);

            // Hiển thị các chuyên ngành trong combobox
            if ($result_major->num_rows > 0) {
                while ($row = $result_major->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['name_major'] . "</option>";
                }
            }

            // Đóng kết nối
            $conn->close();
            ?>
        </select><br>
        <input type="submit" value="Thêm sinh viên">




    </form>
</body>

</html>