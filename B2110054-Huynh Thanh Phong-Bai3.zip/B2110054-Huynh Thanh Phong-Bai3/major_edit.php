<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$id = $_GET['id'];
$sql = "SELECT * FROM major WHERE id = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Không tìm thấy chuyên ngành!";
    exit();
}
?>

<h2>Sửa chuyên ngành</h2>
<form method="POST" action="major_edit_save.php">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
    Tên chuyên ngành: <input type="text" name="name_major" value="<?php echo $row['name_major']; ?>" required><br><br>
    <input type="submit" value="Lưu">
</form>
<a href="major_index.php">Quay lại danh sách</a>