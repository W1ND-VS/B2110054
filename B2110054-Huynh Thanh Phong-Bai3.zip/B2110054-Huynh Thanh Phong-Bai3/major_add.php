<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name_major = $_POST['name_major'];

    $sql = "INSERT INTO major (name_major) VALUES ('$name_major')";
    if ($conn->query($sql) === TRUE) {
        echo "Thêm chuyên ngành thành công";
        header('Location: major_index.php');
    } else {
        echo "Lỗi: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}
?>

<h2>Thêm chuyên ngành mới</h2>
<form method="POST" action="">
    Tên chuyên ngành: <input type="text" name="name_major" required><br><br>
    <input type="submit" value="Thêm">
</form>
<a href="major_index.php">Quay lại danh sách</a>